<?php
/**
 * Title: 教室予約
 * Slug: kiln-theme/booking
 * Categories: kiln-class, kiln-form
 * Description: 予約カレンダーを置く枠。RESERVATION BLOCK を配置して設定します。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"style":{"border":{"color":"var:preset|color|border","style":"dashed","width":"1px","radius":"2px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color" style="border-color:var(--wp--preset--color--border);border-style:dashed;border-width:1px;border-radius:2px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)">
		<!-- wp:paragraph {"align":"center","fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
		<p class="has-text-align-center has-text-color has-small-font-size" style="color:var(--wp--preset--color--muted)">この枠にサイトエディターから RESERVATION BLOCK を配置し、コース（リソース）と時間帯を設定してください。</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
