<?php
/**
 * Title: 技術紹介（動画）
 * Slug: kiln-theme/technique-video
 * Categories: kiln-section
 * Description: 制作風景の動画。動画ブロックを選択してメディアを差し替えてください。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"full","backgroundColor":"contrast","textColor":"base","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-base-color has-contrast-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"textAlign":"center","fontSize":"x-large"} -->
	<h2 class="wp-block-heading has-text-align-center has-x-large-font-size">土が器になるまで</h2>
	<!-- /wp:heading -->

	<!-- wp:video {"align":"wide"} -->
	<figure class="wp-block-video alignwide"></figure>
	<!-- /wp:video -->

	<!-- wp:paragraph {"align":"center","fontSize":"x-small","style":{"color":{"text":"var:preset|color|border"}}} -->
	<p class="has-text-align-center has-text-color has-x-small-font-size" style="color:var(--wp--preset--color--border)">轆轤挽きから窯出しまでの一連の作業</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
