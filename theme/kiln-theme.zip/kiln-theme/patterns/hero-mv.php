<?php
/**
 * Title: ファーストビュー
 * Slug: kiln-theme/hero-mv
 * Categories: kiln-front
 * Description: フロントページ最上部のファーストビュー。itmar/slide-mv などのメインビューブロックに差し替えて使います。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"full","className":"kiln-hero","gradient":"kiln-veil","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"blockGap":"var:preset|spacing|30"},"color":{"text":"var:preset|color|on-image"},"elements":{"link":{"color":{"text":"var:preset|color|on-image"}}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull kiln-hero has-text-color has-link-color has-kiln-veil-gradient-background has-background" style="color:var(--wp--preset--color--on-image);padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
	<!-- wp:paragraph {"align":"center","fontSize":"x-small","style":{"typography":{"letterSpacing":"0.3em"}}} -->
	<p class="has-text-align-center has-x-small-font-size" style="letter-spacing:0.3em">POTTERY STUDIO</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"display","style":{"typography":{"lineHeight":"1.5"}}} -->
	<h1 class="wp-block-heading has-text-align-center has-display-font-size" style="line-height:1.5">土に触れ、<br>火にゆだねる。</h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"medium"} -->
	<p class="has-text-align-center has-medium-font-size">ひとつずつ、手のあとを残して焼き上げています。</p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
	<div class="wp-block-buttons">
		<!-- wp:button {"backgroundColor":"on-image","textColor":"contrast"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-contrast-color has-on-image-background-color has-text-color has-background wp-element-button">作品を見る</a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
