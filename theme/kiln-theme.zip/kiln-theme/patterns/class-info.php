<?php
/**
 * Title: 教室案内（コース表）
 * Slug: kiln-theme/class-info
 * Categories: kiln-class
 * Description: コースと日程の一覧。itmar/design-table に差し替えるとデザイン調整の幅が広がります。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:heading {"fontSize":"x-large"} -->
	<h2 class="wp-block-heading has-x-large-font-size">コースと日程</h2>
	<!-- /wp:heading -->

	<!-- wp:table {"align":"wide","className":"is-style-stripes"} -->
	<figure class="wp-block-table alignwide is-style-stripes"><table><thead><tr><th>コース</th><th>回数</th><th>曜日・時間</th><th>受講料</th></tr></thead><tbody><tr><td>体験</td><td>1回</td><td>土・日 10:00-12:00</td><td>4,000円</td></tr><tr><td>基礎</td><td>全6回</td><td>水 14:00-16:00</td><td>24,000円</td></tr><tr><td>本科</td><td>月4回</td><td>火・木 18:00-20:30</td><td>月 16,000円</td></tr><tr><td>自由制作</td><td>随時</td><td>営業時間内</td><td>1回 3,500円</td></tr></tbody></table></figure>
	<!-- /wp:table -->

	<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
	<p class="has-text-color has-small-font-size" style="color:var(--wp--preset--color--muted)">受講料には土代・焼成代が含まれます。作品の郵送をご希望の場合は別途送料を申し受けます。</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
