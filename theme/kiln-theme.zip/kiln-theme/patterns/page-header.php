<?php
/**
 * Title: ページ見出し
 * Slug: kiln-theme/page-header
 * Inserter: no
 *
 * @package Kiln
 */

?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|40"},"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:post-title {"level":1,"fontSize":"xx-large"} /-->
	<!-- wp:separator {"backgroundColor":"border"} -->
	<hr class="wp-block-separator has-text-color has-border-color has-border-background-color has-background"/>
	<!-- /wp:separator -->
</div>
<!-- /wp:group -->
