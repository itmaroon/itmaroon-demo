<?php
/**
 * Title: 404
 * Slug: kiln-theme/hidden-404
 * Inserter: no
 *
 * @package Kiln
 */

?>
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"align":"center","fontSize":"display","style":{"typography":{"fontFamily":"var:preset|font-family|mincho"},"color":{"text":"var:preset|color|border"}}} -->
	<p class="has-text-align-center has-text-color has-display-font-size" style="color:var(--wp--preset--color--border);font-family:var(--wp--preset--font-family--mincho)">404</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","level":1,"fontSize":"x-large"} -->
	<h1 class="wp-block-heading has-text-align-center has-x-large-font-size">お探しのページが見つかりません</h1>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
	<p class="has-text-align-center has-text-color has-small-font-size" style="color:var(--wp--preset--color--muted)">移動または削除された可能性があります。下の検索をお試しください。</p>
	<!-- /wp:paragraph -->

	<!-- wp:search {"label":"検索","showLabel":false,"placeholder":"作品名やキーワード","buttonText":"検索","buttonPosition":"button-inside"} /-->
</div>
<!-- /wp:group -->
