<?php
/**
 * Title: コンセプト（4項目）
 * Slug: kiln-theme/concept-4
 * Categories: kiln-front, kiln-section
 * Description: フロントページでスクロールしたときに現れるコンセプト4項目。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|50"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group">
		<!-- wp:paragraph {"align":"center","fontSize":"x-small","style":{"typography":{"letterSpacing":"0.3em"},"color":{"text":"var:preset|color|primary"}}} -->
		<p class="has-text-align-center has-text-color has-x-small-font-size" style="color:var(--wp--preset--color--primary);letter-spacing:0.3em">CONCEPT</p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"textAlign":"center","fontSize":"xx-large"} -->
		<h2 class="wp-block-heading has-text-align-center has-xx-large-font-size">四つの約束</h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:group -->

	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"xx-large","style":{"color":{"text":"var:preset|color|border"},"typography":{"fontFamily":"var:preset|font-family|mincho"}}} -->
			<p class="has-text-color has-xx-large-font-size" style="color:var(--wp--preset--color--border);font-family:var(--wp--preset--font-family--mincho)">01</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"large"} -->
			<h3 class="wp-block-heading has-large-font-size">土を選ぶ</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">つくるものに合わせて土を配合します。手に伝わる感触から決めていきます。</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"xx-large","style":{"color":{"text":"var:preset|color|border"},"typography":{"fontFamily":"var:preset|font-family|mincho"}}} -->
			<p class="has-text-color has-xx-large-font-size" style="color:var(--wp--preset--color--border);font-family:var(--wp--preset--font-family--mincho)">02</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"large"} -->
			<h3 class="wp-block-heading has-large-font-size">手で挽く</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">轆轤の上で形を決めます。同じものはひとつとしてありません。</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"xx-large","style":{"color":{"text":"var:preset|color|border"},"typography":{"fontFamily":"var:preset|font-family|mincho"}}} -->
			<p class="has-text-color has-xx-large-font-size" style="color:var(--wp--preset--color--border);font-family:var(--wp--preset--font-family--mincho)">03</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"large"} -->
			<h3 class="wp-block-heading has-large-font-size">釉薬をかける</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">灰や鉄から自家調合した釉薬を使い、色の深みを引き出します。</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"fontSize":"xx-large","style":{"color":{"text":"var:preset|color|border"},"typography":{"fontFamily":"var:preset|font-family|mincho"}}} -->
			<p class="has-text-color has-xx-large-font-size" style="color:var(--wp--preset--color--border);font-family:var(--wp--preset--font-family--mincho)">04</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"large"} -->
			<h3 class="wp-block-heading has-large-font-size">火にゆだねる</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small"} -->
			<p class="has-small-font-size">窯の中で起きることは、すべてを制御できません。そこに景色が生まれます。</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
