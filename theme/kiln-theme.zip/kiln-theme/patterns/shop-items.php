<?php
/**
 * Title: 販売アイテム
 * Slug: kiln-theme/shop-items
 * Categories: kiln-shop
 * Description: 販売する作品の一覧。itmar/product-block と itmar/cart-block を置く枠です。
 *
 * @package Kiln
 */

?>
<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|50"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:heading {"fontSize":"x-large"} -->
	<h2 class="wp-block-heading has-x-large-font-size">販売中の作品</h2>
	<!-- /wp:heading -->

	<!-- wp:group {"style":{"border":{"color":"var:preset|color|border","style":"dashed","width":"1px","radius":"2px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color" style="border-color:var(--wp--preset--color--border);border-style:dashed;border-width:1px;border-radius:2px;padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)">
		<!-- wp:paragraph {"align":"center","fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
		<p class="has-text-align-center has-text-color has-small-font-size" style="color:var(--wp--preset--color--muted)">この枠にサイトエディターから PRODUCT BLOCK を配置し、ショップ連携を設定してください。カート表示が必要な場合はヘッダーに CART BLOCK を追加します。</p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
