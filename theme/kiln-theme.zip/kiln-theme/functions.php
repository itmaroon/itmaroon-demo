<?php
/**
 * Kiln theme functions.
 *
 * @package Kiln
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'kiln_enqueue_styles' ) ) :
	/**
	 * Enqueues the theme stylesheet on the front end.
	 *
	 * Block themes do not load style.css automatically.
	 */
	function kiln_enqueue_styles(): void {
		wp_enqueue_style(
			'kiln-style',
			get_stylesheet_uri(),
			array(),
			wp_get_theme()->get( 'Version' )
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'kiln_enqueue_styles' );

if ( ! function_exists( 'kiln_editor_style' ) ) :
	/**
	 * Applies the same stylesheet inside the editors.
	 */
	function kiln_editor_style(): void {
		add_editor_style( 'style.css' );
	}
endif;
add_action( 'after_setup_theme', 'kiln_editor_style' );

if ( ! function_exists( 'kiln_register_pattern_categories' ) ) :
	/**
	 * Registers the pattern categories used by this theme's patterns.
	 */
	function kiln_register_pattern_categories(): void {
		$categories = array(
			'kiln-front'    => __( 'Kiln: フロントページ', 'kiln-theme' ),
			'kiln-works'    => __( 'Kiln: 作品', 'kiln-theme' ),
			'kiln-shop'     => __( 'Kiln: 販売', 'kiln-theme' ),
			'kiln-class'    => __( 'Kiln: 教室', 'kiln-theme' ),
			'kiln-form'     => __( 'Kiln: フォーム', 'kiln-theme' ),
			'kiln-section'  => __( 'Kiln: セクション', 'kiln-theme' ),
		);

		foreach ( $categories as $slug => $label ) {
			register_block_pattern_category( $slug, array( 'label' => $label ) );
		}
	}
endif;
add_action( 'init', 'kiln_register_pattern_categories' );
